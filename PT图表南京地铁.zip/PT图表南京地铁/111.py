import pandas as pd
import matplotlib.pyplot as plt
df=pd.read_excel(r'D:\金陵红\PT图表南京地铁\客流.xlsx')
x=[1,2,3,4,5]
y1=df['5号线客流']
y2=df['1号线客流']
fig = plt.figure()
plt.rcParams['font.sans-serif']=['SimHei']
plt.rcParams['axes.unicode_minus'] = False
ax = fig.add_subplot(111)
plt.title('南京地铁5号线和1号线近5日客流')
plt.xticks(x,['9.11','9.12','9.13','9.14','9.15'])
line1,=ax.plot(x,y1,color='yellow',linestyle='--',marker='o',linewidth=2,label=u"客流")
line2,=ax.plot(x,y2,color='blue',linestyle='--',marker='o',linewidth=2,label=u"客流")
ax.set_label(u"客流")
for a,b in zip(x,y1):
    plt.text(a, b+1, '%.2f' % b, ha='center', va= 'bottom',fontsize=10,color='red')
for a,b in zip(x,y2):
    plt.text(a, b-3, '%.2f' % b, ha='center', va= 'bottom',fontsize=10,color='green')
plt.show()

